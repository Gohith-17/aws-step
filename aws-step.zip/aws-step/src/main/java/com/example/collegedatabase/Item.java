package com.example.collegedatabase;

import java.util.Date;

public class Item {
    private int id;
    private String name;
    private String description;
    private double price;
    private Date manufactureDate;
    private String category;

    public Item(int id, String name, String description, double price, Date manufactureDate, String category) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.manufactureDate = manufactureDate;
        this.category = category;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public Date getManufactureDate() {
        return manufactureDate;
    }

    public String getCategory() {
        return category;
    }
    
    // Setters, toString(), and other methods as needed...
}
